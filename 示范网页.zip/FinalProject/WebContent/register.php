<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>register</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>
<?php
  session_start (); 
  $Reg="";
  if (isset($_SESSION['RegStatus'])) {
      $Reg = $_SESSION['RegStatus'];
	 unset($_SESSION['RegStatus']);
 }
?>
  <a href="home.php" class="returnHome"><code>-> Home</code></a>
  <div class="account">
  <code style="font-size:25px;">Register a new account</code><br><br><br>
  <form action="controller.php" method="post">
  <code style="font-size:17px;">User name*</code><br>
  <input type="text" pattern=".{4,}" name="username" class="accountInput"><br><br>
  <code style="font-size:17px;">Password*</code><br>
  <input type="password" pattern=".{6,}" name="password" class="accountInput"><br><br>
  <input type="submit" value="Register" class="submitButton" name="register">
  </form>
<?php
if ($Reg== "exist"){
   echo "Account name already exits";
}
?>  
</div>
</body>
</html>