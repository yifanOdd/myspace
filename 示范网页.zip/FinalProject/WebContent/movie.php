<!DOCTYPE html>
<html>
<head>
<!-- Xuwei Zhang -->
<title>Movie Reviews</title>
<meta charset="utf-8" />
<link href="style.css" type="text/css" rel="stylesheet" />
</head>
<?php
session_start ();
$movieName = $_GET["movieName"];

$login="";
if (isset($_SESSION['loginStatus'])) {
	$login= $_SESSION['loginStatus'];
}

$login = htmlspecialchars($login);

if ($login != "valid"){
	$username = "guest";
} else {
	if(isset($_SESSION['username'])){
	    $username= $_SESSION["username"];
     	$username = htmlspecialchars($username);
	}
}
?>

<body onload="show()">

<a href="home.php" class="returnHome"><code>-> Home</code></a>
<div class="movieFrame" id="frame">
<div class="movieInfo"></div>
</div>


<script>
function show(){
	var str ="";
    var movieInfo=document.getElementById("movieInfo");
    var anObj = new XMLHttpRequest();
    anObj.open("GET", "controller.php?movieName=" + <?php $movieName?> , true);
    anObj.send();
    anObj.onreadystatechange = function() {
	   if (anObj.readyState == 4 && anObj.status == 200) {
		  var info = JSON.parse(anObj.responseText);
          str += '<div class="rateBox">';
          str += info['rating'];
          str += '</div>';
          str += '<div class="movieName"><code>';
          str += info['name'];
          str += '</code></div>';
		  str += '<img class="movieImage" src="../images/';
		  str += info['name'];
		  str += '.JPG" />';
          str += '<ul class="movieul">';
          str += '<li><a><code>Director:';
          str += info['director'];
          str += '</code></a></li>';
          str += '<li><a><code>Actors:';
          str += info['actors'];
          str += '</code></a></li>';
          str += '<li><a><code>Type:';
          str += info['type'];
          str += '</code></a></li>';
          str += '<li><a><code>Release Date:';
          str += info['release_date'];
          str += '</code></a></li>';
          str += '<li><a><code>Length:';
          str += info['length'];
          str += '</code></a></li>';
          str += '</ul>';
          str += '<br/>';     
          str += '<hr style="border-top: dotted 1px;color: black;" />';
          str += '<div class="des"><code>Description · · · · · ·</code></div>';
          str += '<div class="destxt">';
          str += info['description'];
          str += '</div>';
          str += '<br/><br/><div class="des"><code>Review · · · · · ·</code></div>';
          str += '<div id="reviews">';
          str += '</div>';

          movieInfo.innerHTML = str; 
	   }
  }
}
</script>

</body>
</html>