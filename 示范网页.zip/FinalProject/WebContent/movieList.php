<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Movie List</title>
</head>

<?php 
$type = $_GET['type'];
?>

<body onload="showAll()" class="movieListBody">

<div id="allMovies"></div>

<script>
function showAll() {
	  var allMovies = document.getElementById("allMovies"); 
	  var moviesDisplay = '';
	  moviesDisplay += '<div id="header">';
	  moviesDisplay += '<div><code>';
	  moviesDisplay += <?php $type?>;
	  moviesDisplay += '</code></div>';
	  moviesDisplay += '<a id="back" href="home.php">home</a>';
	  moviesDisplay += '</div>';
	  
	  var ajax = new XMLHttpRequest();
	  ajax.open("GET", "controller.php?type=" + <?php $type?>, true);
	  ajax.send(); 
	  ajax.onreadystatechange = function () {
		  if (ajax.readyState == 4 && ajax.status == 200) {
			  var array = JSON.parse(ajax.responseText);
			  for (var i=0; i<array.length; i++){
			     moviesDisplay += '<div class="oneMovie">';
			     moviesDisplay += '<a href="movie.php?movieName=';
			     moviesDisplay += array[i]['name'];
				 moviesDisplay += '">';
			     moviesDisplay += '<img class="listImg" src="';
			     moviesDisplay += array[i]['name'];
			     moviesDisplay += '/cover.jpg"';
			     moviesDisplay += '>';
			     moviesDisplay += '</a>'
			     moviesDisplay += '</div>';
			  }
			 // alert(imagesDisplay);
			  allMovies.innerHTML = moviesDisplay;
		  }
	   }
	  }
</script>

</body>
</html>