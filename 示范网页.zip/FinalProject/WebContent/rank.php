<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Ranking List</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>
  <div class="rankHead"><code>Ranking List</code></div>
  <hr style="border-top: dotted 1px;color: #fff;" />
  <div id="rankingList"></div>
  
<script>
var rank=document.getElementById("rankingList");
var anObj = new XMLHttpRequest();
anObj.open("GET", "controller.php", true);
anObj.send();
anObj.onreadystatechange = function() {
	if (anObj.readyState == 4 && anObj.status == 200) {
		var array = JSON.parse(anObj.responseText);
		var str = "";
		for (i = 0; i < 10; i++){
       
		}
		divToChange.innerHTML += str;
	}
}
</script>
</body>
</html>