<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Log In</title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>
<?php
  session_start (); 
  $login="";
  if (isset($_SESSION['loginStatus'])) {
     $login = $_SESSION['loginStatus'];
	 unset($_SESSION['loginStatus']);
 }
?>
  <a href="home.php" class="returnHome"><code>-> Home</code></a>
  <div class="account">
  <code style="font-size:25px;">Log in with an existing account</code><br><br><br>
  <form action="controller.php" method="post">
  <code style="font-size:17px;">User name*</code><br>
  <input type="text" pattern=".{4,}" name="username" class="accountInput"><br><br>
  <code style="font-size:17px;">Password*</code><br>
  <input type="password" pattern=".{6,}" name="password" class="accountInput"><br><br>
  <input type="submit" value="Login" class="submitButton" name="login">
  </form>
<?php
if ($login == "invalid"){
   echo "Invalid username or password";
}
?>
  </div>
</body>
</html>
